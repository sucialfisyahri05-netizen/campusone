
package com.example.campusone;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.util.ArrayList;

public class TaskActivity extends Activity {

    private JSONArray data;
    private ArrayList<String> labels;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tasks);

        data = LocalData.get(this, "tasks");

        labels = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                labels
        );

        ListView list = findViewById(R.id.taskList);
        list.setAdapter(adapter);

        refresh();

        // Tambah tugas
        findViewById(R.id.addTask).setOnClickListener(v ->
                editTask(-1)
        );

        // Ketuk tugas untuk edit
        list.setOnItemClickListener((parent, view, position, id) ->
                editTask(position)
        );

        // Tekan lama untuk hapus
        list.setOnItemLongClickListener(
                (parent, view, position, id) -> {

                    new AlertDialog.Builder(this)
                            .setTitle("Hapus Tugas")
                            .setMessage("Yakin ingin menghapus tugas ini?")
                            .setNegativeButton("Batal", null)
                            .setPositiveButton("Hapus", (dialog, which) -> {

                                data.remove(position);

                                save();
                                refresh();

                                Toast.makeText(
                                        this,
                                        "Tugas berhasil dihapus",
                                        Toast.LENGTH_SHORT
                                ).show();

                            })
                            .show();

                    return true;
                }
        );
    }

    private void editTask(int position) {

        EditText input = new EditText(this);
        input.setHint("Nama tugas");
        input.setPadding(30, 20, 30, 20);

        if (position >= 0) {

            JSONObject old = data.optJSONObject(position);

            if (old != null) {
                input.setText(old.optString("title"));
            }
        }

        new AlertDialog.Builder(this)
                .setTitle(position < 0 ? "Tambah Tugas" : "Edit Tugas")
                .setView(input)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", (dialog, which) -> {

                    String title = input.getText()
                            .toString().trim();

                    if (title.isEmpty()) {

                        Toast.makeText(
                                this,
                                "Nama tugas wajib diisi",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }

                    JSONObject item = new JSONObject();

                    try {

                        item.put("title", title);

                        if (position < 0) {
                            data.put(item);
                        } else {
                            data.put(position, item);
                        }

                    } catch (JSONException e) {

                        Toast.makeText(
                                this,
                                "Gagal menyimpan tugas",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }

                    save();
                    refresh();

                    Toast.makeText(
                            this,
                            "Tugas berhasil disimpan",
                            Toast.LENGTH_SHORT
                    ).show();

                })
                .show();
    }

    private void save() {
        LocalData.save(this, "tasks", data);
    }

    private void refresh() {

        labels.clear();

        for (int i = 0; i < data.length(); i++) {

            JSONObject item = data.optJSONObject(i);

            if (item != null) {
                labels.add(item.optString("title"));
            }
        }

        adapter.notifyDataSetChanged();
    }
}