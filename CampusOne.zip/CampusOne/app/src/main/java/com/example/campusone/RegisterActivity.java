
package com.example.campusone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.*;

public class RegisterActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        setContentView(R.layout.activity_register);

        EditText name = findViewById(R.id.name);
        EditText nim = findViewById(R.id.nim);
        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.password);
        EditText confirm = findViewById(R.id.confirmPassword);

        findViewById(R.id.registerButton).setOnClickListener(v -> {

            String n = name.getText().toString().trim();
            String no = nim.getText().toString().trim();
            String e = email.getText().toString().trim();
            String p = password.getText().toString();
            String cp = confirm.getText().toString();

            if (n.isEmpty() || no.isEmpty() ||
                    e.isEmpty() || p.isEmpty() || cp.isEmpty()) {

                Toast.makeText(this, "Semua data wajib diisi",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(e).matches()) {
                email.setError("Email tidak valid");
                return;
            }

            if (p.length() < 6) {
                password.setError("Minimal 6 karakter");
                return;
            }

            if (!p.equals(cp)) {
                confirm.setError("Password tidak sama");
                return;
            }

            if (!Session.register(this, n, no, e, p)) {
                Toast.makeText(this, "Akun sudah terdaftar",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(this, "Registrasi berhasil",
                    Toast.LENGTH_SHORT).show();

            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        findViewById(R.id.goLogin).setOnClickListener(v ->
                startActivity(new Intent(this, LoginActivity.class))
        );
    }
}
