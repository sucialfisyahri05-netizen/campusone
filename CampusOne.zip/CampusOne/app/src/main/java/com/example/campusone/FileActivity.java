
package com.example.campusone;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.util.ArrayList;

public class FileActivity extends Activity {

    private static final int PICK_FILE = 100;

    private JSONArray savedFiles;
    private ArrayList<Uri> fileUris;
    private ArrayList<String> fileNames;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file);

        ListView fileList = findViewById(R.id.fileList);

        fileUris = new ArrayList<>();
        fileNames = new ArrayList<>();

        savedFiles = LocalData.get(this, "saved_files");

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                fileNames
        );

        fileList.setAdapter(adapter);

        refreshFiles();

        // Pilih file baru
        findViewById(R.id.pickFile).setOnClickListener(v ->
                openFilePicker()
        );

        // Ketuk untuk membuka
        fileList.setOnItemClickListener((parent, view, position, id) ->
                openSavedFile(position)
        );

        // Tekan lama untuk menghapus dari daftar
        fileList.setOnItemLongClickListener(
                (parent, view, position, id) -> {

                    new AlertDialog.Builder(this)
                            .setTitle("Hapus File")
                            .setMessage("Hapus file dari daftar CampusOne?")
                            .setNegativeButton("Batal", null)
                            .setPositiveButton("Hapus", (dialog, which) -> {

                                savedFiles.remove(position);

                                saveFiles();
                                refreshFiles();

                            })
                            .show();

                    return true;
                }
        );
    }

    private void openFilePicker() {

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);

        intent.setType("*/*");

        intent.addCategory(Intent.CATEGORY_OPENABLE);

        intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        );

        startActivityForResult(intent, PICK_FILE);
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent result
    ) {
        super.onActivityResult(requestCode, resultCode, result);

        if (requestCode == PICK_FILE &&
                resultCode == RESULT_OK &&
                result != null &&
                result.getData() != null) {

            Uri uri = result.getData();

            try {

                getContentResolver().takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                );

                // Cek duplikat
                for (int i = 0; i < savedFiles.length(); i++) {

                    JSONObject old = savedFiles.optJSONObject(i);

                    if (old != null &&
                            uri.toString().equals(old.optString("uri"))) {

                        Toast.makeText(
                                this,
                                "File sudah tersimpan",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }
                }

                JSONObject item = new JSONObject();

                item.put("uri", uri.toString());
                item.put("name", getFileName(uri));

                savedFiles.put(item);

                saveFiles();
                refreshFiles();

                Toast.makeText(
                        this,
                        "File berhasil disimpan",
                        Toast.LENGTH_SHORT
                ).show();

            } catch (Exception e) {

                Toast.makeText(
                        this,
                        "Gagal menyimpan file",
                        Toast.LENGTH_SHORT
                ).show();
            }
        }
    }

    private String getFileName(Uri uri) {

        String name = "Dokumen";

        Cursor cursor = getContentResolver()
                .query(uri, null, null, null, null);

        if (cursor != null) {

            try {

                if (cursor.moveToFirst()) {

                    int index = cursor.getColumnIndex(
                            OpenableColumns.DISPLAY_NAME
                    );

                    if (index >= 0) {
                        name = cursor.getString(index);
                    }
                }

            } finally {
                cursor.close();
            }
        }

        return name;
    }

    private void refreshFiles() {

        fileUris.clear();
        fileNames.clear();

        for (int i = 0; i < savedFiles.length(); i++) {

            JSONObject item = savedFiles.optJSONObject(i);

            if (item != null) {

                Uri uri = Uri.parse(item.optString("uri"));

                String name = item.optString("name");

                fileUris.add(uri);

                fileNames.add(
                        "📄  " + name +
                                "\nKetuk untuk membuka • Tekan lama untuk hapus"
                );
            }
        }

        adapter.notifyDataSetChanged();

        TextView count = findViewById(R.id.fileCount);

        if (count != null) {
            count.setText(fileNames.size() + " File Tersimpan");
        }

        TextView empty = findViewById(R.id.emptyText);

        if (empty != null) {
            empty.setVisibility(
                    fileNames.isEmpty() ? View.VISIBLE : View.GONE
            );
        }
    }

    private void openSavedFile(int position) {

        Uri uri = fileUris.get(position);

        String type = getContentResolver().getType(uri);

        if (type == null) {
            type = "*/*";
        }

        Intent intent = new Intent(Intent.ACTION_VIEW);

        intent.setDataAndType(uri, type);

        intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION
        );

        try {

            startActivity(intent);

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Tidak ada aplikasi untuk membuka file",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void saveFiles() {
        LocalData.save(this, "saved_files", savedFiles);
    }
}