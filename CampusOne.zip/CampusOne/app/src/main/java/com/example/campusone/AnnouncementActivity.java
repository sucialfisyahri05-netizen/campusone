
package com.example.campusone;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.util.ArrayList;

public class AnnouncementActivity extends Activity {

    private JSONArray data;
    private ArrayList<String> rows;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcements);

        data = LocalData.get(this, "announcements");

        rows = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                rows
        );

        ListView list = findViewById(R.id.announcementList);
        list.setAdapter(adapter);

        refresh();

        findViewById(R.id.addAnnouncement).setOnClickListener(v ->
                editAnnouncement(-1)
        );

        list.setOnItemClickListener((parent, view, position, id) ->
                editAnnouncement(position)
        );

        list.setOnItemLongClickListener((parent, view, position, id) -> {

            new AlertDialog.Builder(this)
                    .setTitle("Hapus Informasi")
                    .setMessage("Yakin ingin menghapus pengumuman ini?")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus", (dialog, which) -> {
                        data.remove(position);
                        save();
                        refresh();
                    })
                    .show();

            return true;
        });
    }

    private void editAnnouncement(int position) {

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(30, 10, 30, 10);

        EditText title = new EditText(this);
        title.setHint("Judul pengumuman");

        EditText body = new EditText(this);
        body.setHint("Isi informasi");
        body.setMinLines(3);
        body.setGravity(android.view.Gravity.TOP);

        form.addView(title);
        form.addView(body);

        if (position >= 0) {

            JSONObject old = data.optJSONObject(position);

            if (old != null) {
                title.setText(old.optString("title"));
                body.setText(old.optString("body"));
            }
        }

        new AlertDialog.Builder(this)
                .setTitle(position < 0 ? "Tambah Informasi" : "Edit Informasi")
                .setView(form)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", (dialog, which) -> {

                    String t = title.getText().toString().trim();
                    String b = body.getText().toString().trim();

                    if (t.isEmpty() || b.isEmpty()) {
                        Toast.makeText(
                                this,
                                "Judul dan isi wajib diisi",
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }

                    JSONObject item = new JSONObject();

                    try {
                        item.put("title", t);
                        item.put("body", b);

                        if (position < 0) {
                            data.put(item);
                        } else {
                            data.put(position, item);
                        }

                    } catch (JSONException e) {
                        Toast.makeText(
                                this,
                                "Gagal menyimpan informasi",
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }

                    save();
                    refresh();

                    Toast.makeText(
                            this,
                            "Informasi berhasil disimpan",
                            Toast.LENGTH_SHORT
                    ).show();
                })
                .show();
    }

    private void save() {
        LocalData.save(this, "announcements", data);
    }

    private void refresh() {

        rows.clear();

        for (int i = 0; i < data.length(); i++) {

            JSONObject item = data.optJSONObject(i);

            if (item != null) {
                rows.add(
                        item.optString("title") +
                                "\n" +
                                item.optString("body")
                );
            }
        }

        adapter.notifyDataSetChanged();
    }
}