
package com.example.campusone;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.*;

public class ProfileActivity extends Activity {

    private TextView name;
    private TextView nim;
    private TextView email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        name = findViewById(R.id.profileName);
        nim = findViewById(R.id.profileNim);
        email = findViewById(R.id.profileEmail);

        refresh();

        findViewById(R.id.editProfile).setOnClickListener(v ->
                editProfile()
        );
    }

    private void refresh() {

        name.setText("Nama: " + Session.getName(this));

        nim.setText("NIM: " + Session.getNim(this));

        email.setText("Email: " + Session.getEmail(this));
    }

    private void editProfile() {

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(30, 10, 30, 10);

        EditText inputName = new EditText(this);
        inputName.setHint("Nama lengkap");
        inputName.setText(Session.getName(this));

        EditText inputNim = new EditText(this);
        inputNim.setHint("NIM");
        inputNim.setText(Session.getNim(this));

        form.addView(inputName);
        form.addView(inputNim);

        new AlertDialog.Builder(this)
                .setTitle("Edit Profil")
                .setView(form)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", (dialog, which) -> {

                    String n = inputName.getText().toString().trim();
                    String no = inputNim.getText().toString().trim();

                    if (n.isEmpty() || no.isEmpty()) {
                        Toast.makeText(
                                this,
                                "Nama dan NIM wajib diisi",
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }

                    Session.updateProfile(this, n, no);

                    refresh();

                    Toast.makeText(
                            this,
                            "Profil berhasil diperbarui",
                            Toast.LENGTH_SHORT
                    ).show();
                })
                .show();
    }
}