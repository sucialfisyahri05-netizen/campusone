
package com.example.campusone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

public class LoginActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        setContentView(R.layout.activity_login);

        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.password);

        findViewById(R.id.loginButton).setOnClickListener(v -> {

            String e = email.getText().toString().trim();
            String p = password.getText().toString();

            if (e.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Isi email dan password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (Session.login(this, e, p)) {

                startActivity(new Intent(this, DashboardActivity.class));
                finish();

            } else {

                Toast.makeText(this, "Login gagal",
                        Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.goRegister).setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class))
        );
    }
}
