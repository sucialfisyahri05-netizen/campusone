package com.example.campusone;

import android.content.Context;
import android.content.SharedPreferences;

public class Session {

    private static final String PREF = "CampusOneData";

    private static SharedPreferences getPrefs(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static boolean register(
            Context c, String name, String nim,
            String email, String password) {

        SharedPreferences p = getPrefs(c);

        if (p.contains("email")) return false;

        p.edit()
                .putString("name", name)
                .putString("nim", nim)
                .putString("email", email)
                .putString("password", password)
                .apply();

        return true;
    }

    public static boolean login(
            Context c, String email, String password) {

        SharedPreferences p = getPrefs(c);

        return email.equals(p.getString("email", ""))
                && password.equals(p.getString("password", ""));
    }

    public static String getName(Context c) {
        return getPrefs(c).getString("name", "Mahasiswa");
    }

    public static String getNim(Context c) {
        return getPrefs(c).getString("nim", "");
    }

    public static String getEmail(Context c) {
        return getPrefs(c).getString("email", "");
    }

    public static void updateProfile(
            Context c, String name, String nim) {

        getPrefs(c).edit()
                .putString("name", name)
                .putString("nim", nim)
                .apply();
    }
}
