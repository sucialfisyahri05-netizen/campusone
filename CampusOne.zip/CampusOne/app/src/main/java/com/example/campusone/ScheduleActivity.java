
package com.example.campusone;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.util.ArrayList;

public class ScheduleActivity extends Activity {

    private JSONArray data;
    private ArrayList<String> rows;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        data = LocalData.get(this, "schedule");

        rows = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                rows
        );

        ListView list = findViewById(R.id.scheduleList);
        list.setAdapter(adapter);

        refresh();

        findViewById(R.id.addSchedule).setOnClickListener(v ->
                editSchedule(-1)
        );

        list.setOnItemClickListener((parent, view, position, id) ->
                editSchedule(position)
        );

        list.setOnItemLongClickListener((parent, view, position, id) -> {

            new AlertDialog.Builder(this)
                    .setTitle("Hapus Jadwal")
                    .setMessage("Yakin ingin menghapus jadwal ini?")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus", (dialog, which) -> {
                        data.remove(position);
                        save();
                        refresh();
                    })
                    .show();

            return true;
        });
    }

    private void editSchedule(int position) {

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(30, 10, 30, 10);

        EditText course = new EditText(this);
        course.setHint("Nama mata kuliah");

        EditText day = new EditText(this);
        day.setHint("Hari perkuliahan");

        EditText time = new EditText(this);
        time.setHint("Jam dan ruangan");

        form.addView(course);
        form.addView(day);
        form.addView(time);

        if (position >= 0) {

            JSONObject old = data.optJSONObject(position);

            if (old != null) {
                course.setText(old.optString("course"));
                day.setText(old.optString("day"));
                time.setText(old.optString("time"));
            }
        }

        new AlertDialog.Builder(this)
                .setTitle(position < 0 ? "Tambah Jadwal" : "Edit Jadwal")
                .setView(form)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", (dialog, which) -> {

                    String c = course.getText().toString().trim();
                    String d = day.getText().toString().trim();
                    String t = time.getText().toString().trim();

                    if (c.isEmpty() || d.isEmpty() || t.isEmpty()) {
                        Toast.makeText(
                                this,
                                "Semua data wajib diisi",
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }

                    JSONObject item = new JSONObject();

                    try {
                        item.put("course", c);
                        item.put("day", d);
                        item.put("time", t);

                        if (position < 0) {
                            data.put(item);
                        } else {
                            data.put(position, item);
                        }

                    } catch (JSONException e) {
                        Toast.makeText(
                                this,
                                "Gagal menyimpan jadwal",
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }

                    save();
                    refresh();

                    Toast.makeText(
                            this,
                            "Jadwal berhasil disimpan",
                            Toast.LENGTH_SHORT
                    ).show();
                })
                .show();
    }

    private void save() {
        LocalData.save(this, "schedule", data);
    }

    private void refresh() {

        rows.clear();

        for (int i = 0; i < data.length(); i++) {

            JSONObject item = data.optJSONObject(i);

            if (item != null) {
                rows.add(
                        item.optString("course") + "\n" +
                                item.optString("day") + " | " +
                                item.optString("time")
                );
            }
        }

        adapter.notifyDataSetChanged();
    }
}