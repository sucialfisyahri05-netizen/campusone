
package com.example.campusone;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONException;

public class LocalData {

    public static JSONArray get(Context c, String key) {

        String raw = c.getSharedPreferences(
                "CampusOneLocal",
                Context.MODE_PRIVATE
        ).getString(key, "[]");

        try {
            return new JSONArray(raw);
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    public static void save(
            Context c, String key, JSONArray data) {

        c.getSharedPreferences(
                "CampusOneLocal",
                Context.MODE_PRIVATE
        ).edit()
                .putString(key, data.toString())
                .apply();
    }
}
