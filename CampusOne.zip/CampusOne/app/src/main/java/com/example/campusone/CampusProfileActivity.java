
package com.example.campusone;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class CampusProfileActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_campus_profile);

        TextView campusName =
                findViewById(R.id.campusName);

        TextView campusHistory =
                findViewById(R.id.campusHistory);

        TextView campusStudy =
                findViewById(R.id.campusStudy);

        TextView campusLeader =
                findViewById(R.id.campusLeader);

        TextView campusContact =
                findViewById(R.id.campusContact);

        // IDENTITAS KAMPUS
        campusName.setText(
                "Sekolah Tinggi Ilmu Komputer Tunas Bangsa"
        );

        // SEJARAH
        campusHistory.setText(
                "STIKOM Tunas Bangsa berawal dari " +
                        "Akademi Manajemen Informatika Komputer " +
                        "Tunas Bangsa (AMIK) yang berdiri pada tahun 2003.\n\n" +

                        "STIKOM Tunas Bangsa berdiri pada " +
                        "11 September 2014.\n\n" +

                        "Pada tanggal 13 Juli 2022, " +
                        "AMIK dan STIKOM disatukan menjadi " +
                        "Sekolah Tinggi Ilmu Komputer Tunas Bangsa."
        );

        // PROGRAM STUDI
        campusStudy.setText(
                "PROGRAM DIPLOMA\n\n" +
                        "1. Manajemen Informatika\n" +
                        "2. Komputerisasi Akuntansi\n\n" +

                        "PROGRAM SARJANA\n\n" +
                        "3. Sistem Informasi\n" +
                        "4. Teknik Informatika\n\n" +

                        "PROGRAM MAGISTER\n\n" +
                        "5. Informatika S2"
        );

        // PIMPINAN
        campusLeader.setText(
                "Informasi pimpinan kampus dapat dilihat " +
                        "melalui halaman profil resmi STIKOM " +
                        "Tunas Bangsa.\n\n" +
                        "Website: stikomtunasbangsa.ac.id"
        );

        // KONTAK
        campusContact.setText(
                "STIKOM Tunas Bangsa\n\n" +
                        "Telepon: (0622) 22431\n\n" +
                        "Website:\n" +
                        "https://stikomtunasbangsa.ac.id"
        );
    }
}
