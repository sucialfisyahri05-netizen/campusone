
package com.example.campusone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.animation.ValueAnimator;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.TextView;

public class DashboardActivity extends Activity {

    private ValueAnimator hologramAnimator;
    private ValueAnimator lineAnimator;
    private AnimatorSet welcomeAnimator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_dashboard);

        // =================================
        // 1. NAMA MAHASISWA
        // =================================

        TextView studentName =
                findViewById(R.id.studentName);

        TextView greeting =
                findViewById(R.id.greeting);

        studentName.setText(Session.getName(this));

        greeting.setText("Halo, selamat datang!");

        // =================================
        // 2. ANIMASI DASHBOARD
        // =================================

        View content =
                findViewById(R.id.dashboardContent);

        AlphaAnimation fade =
                new AlphaAnimation(0f, 1f);

        fade.setDuration(900);

        content.startAnimation(fade);

        // =================================
        // 3. ANIMASI WELCOME BACK
        // =================================

        startWelcomeAnimation();

        // =================================
        // 4. ANIMASI HOLOGRAM TOMBOL
        // =================================

        View taskButton =
                findViewById(R.id.tasksButton);

        animateHologram(taskButton);

        // =================================
        // 5. ANIMASI GARIS HOLOGRAM
        // =================================

        View holoLine =
                findViewById(R.id.holoLine);

        lineAnimator = ValueAnimator.ofFloat(0.35f, 1f);

        lineAnimator.setDuration(1500);

        lineAnimator.setRepeatCount(
                ValueAnimator.INFINITE
        );

        lineAnimator.setRepeatMode(
                ValueAnimator.REVERSE
        );

        lineAnimator.addUpdateListener(animation -> {

            holoLine.setAlpha(
                    (float) animation.getAnimatedValue()
            );

        });

        lineAnimator.start();

        // =================================
        // 6. MENU AKADEMIK
        // =================================

        findViewById(R.id.scheduleButton)
                .setOnClickListener(v ->
                        openPage(ScheduleActivity.class)
                );

        findViewById(R.id.tasksButton)
                .setOnClickListener(v ->
                        openPage(TaskActivity.class)
                );

        findViewById(R.id.gradesButton)
                .setOnClickListener(v ->
                        openPage(GradeActivity.class)
                );

        findViewById(R.id.infoButton)
                .setOnClickListener(v ->
                        openPage(AnnouncementActivity.class)
                );

        findViewById(R.id.filesButton)
                .setOnClickListener(v ->
                        openPage(FileActivity.class)
                );

        findViewById(R.id.profileButton)
                .setOnClickListener(v ->
                        openPage(ProfileActivity.class)
                );

        findViewById(R.id.campusProfileButton)
                .setOnClickListener(v ->
                        openPage(CampusProfileActivity.class)
                );

        // =================================
        // 7. BOTTOM NAVIGATION
        // =================================

        findViewById(R.id.navHome)
                .setOnClickListener(v -> {
                    // Sudah berada di Beranda
                });

        findViewById(R.id.navSchedule)
                .setOnClickListener(v ->
                        openPage(ScheduleActivity.class)
                );

        findViewById(R.id.navTasks)
                .setOnClickListener(v ->
                        openPage(TaskActivity.class)
                );

        findViewById(R.id.navInfo)
                .setOnClickListener(v ->
                        openPage(AnnouncementActivity.class)
                );

        findViewById(R.id.navProfile)
                .setOnClickListener(v ->
                        openPage(ProfileActivity.class)
                );

        // =================================
        // 8. LOGOUT
        // =================================

        findViewById(R.id.logoutButton)
                .setOnClickListener(v -> {

                    Intent intent = new Intent(
                            DashboardActivity.this,
                            LoginActivity.class
                    );

                    intent.setFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK |
                                    Intent.FLAG_ACTIVITY_CLEAR_TASK
                    );

                    startActivity(intent);

                    finish();
                });
    }

    // =====================================
    // MEMBUKA HALAMAN
    // =====================================

    private void openPage(Class<?> page) {

        Intent intent = new Intent(this, page);

        startActivity(intent);
    }

    // =====================================
    // ANIMASI WELCOME BACK
    // =====================================

    private void startWelcomeAnimation() {

        // Bintang hologram
        View sparkle =
                findViewById(R.id.welcomeSparkle);

        // Bergerak naik turun
        ObjectAnimator floatUp = ObjectAnimator.ofFloat(
                sparkle,
                "translationY",
                0f,
                -12f
        );

        floatUp.setDuration(1300);

        floatUp.setRepeatCount(
                ValueAnimator.INFINITE
        );

        floatUp.setRepeatMode(
                ValueAnimator.REVERSE
        );

        // Bintang berputar
        ObjectAnimator rotate = ObjectAnimator.ofFloat(
                sparkle,
                "rotation",
                0f,
                25f,
                -25f,
                0f
        );

        rotate.setDuration(2600);

        rotate.setRepeatCount(
                ValueAnimator.INFINITE
        );

        // Efek cahaya
        ObjectAnimator sparkleAlpha =
                ObjectAnimator.ofFloat(
                        sparkle,
                        "alpha",
                        0.45f,
                        1f
                );

        sparkleAlpha.setDuration(1100);

        sparkleAlpha.setRepeatCount(
                ValueAnimator.INFINITE
        );

        sparkleAlpha.setRepeatMode(
                ValueAnimator.REVERSE
        );

        // Animasi nama mahasiswa
        View name =
                findViewById(R.id.studentName);

        ObjectAnimator nameMove =
                ObjectAnimator.ofFloat(
                        name,
                        "translationY",
                        8f,
                        0f
                );

        nameMove.setDuration(900);

        ObjectAnimator nameFade =
                ObjectAnimator.ofFloat(
                        name,
                        "alpha",
                        0f,
                        1f
                );

        nameFade.setDuration(1100);

        // Jalankan bersama
        welcomeAnimator = new AnimatorSet();

        welcomeAnimator.playTogether(
                floatUp,
                rotate,
                sparkleAlpha,
                nameMove,
                nameFade
        );

        welcomeAnimator.setInterpolator(
                new AccelerateDecelerateInterpolator()
        );

        welcomeAnimator.start();
    }

    // =====================================
    // ANIMASI WARNA HOLOGRAM
    // =====================================

    private void animateHologram(View view) {

        int[] colors = {

                0xFF7950A5,
                0xFFB9A2F5,
                0xFF7DE7E8,
                0xFFF5BCE5,
                0xFF7950A5
        };

        hologramAnimator =
                ValueAnimator.ofFloat(0f, 1f);

        hologramAnimator.setDuration(4000);

        hologramAnimator.setRepeatCount(
                ValueAnimator.INFINITE
        );

        hologramAnimator.addUpdateListener(animation -> {

            float progress =
                    (float) animation.getAnimatedValue();

            float position =
                    progress * (colors.length - 1);

            int index = Math.min(
                    (int) position,
                    colors.length - 2
            );

            float fraction = position - index;

            int middle = blendColor(
                    colors[index],
                    colors[index + 1],
                    fraction
            );

            GradientDrawable gradient =
                    new GradientDrawable(
                            GradientDrawable.Orientation.LEFT_RIGHT,
                            new int[]{
                                    colors[index],
                                    middle,
                                    colors[index + 1]
                            }
                    );

            gradient.setCornerRadius(
                    18 * getResources()
                            .getDisplayMetrics().density
            );

            view.setBackground(gradient);
        });

        hologramAnimator.start();
    }

    // =====================================
    // PERUBAHAN WARNA
    // =====================================

    private int blendColor(
            int start,
            int end,
            float ratio
    ) {

        int a = (int) (
                android.graphics.Color.alpha(start) * (1-ratio)
                        + android.graphics.Color.alpha(end) * ratio
        );

        int r = (int) (
                android.graphics.Color.red(start) * (1-ratio)
                        + android.graphics.Color.red(end) * ratio
        );

        int g = (int) (
                android.graphics.Color.green(start) * (1-ratio)
                        + android.graphics.Color.green(end) * ratio
        );

        int b = (int) (
                android.graphics.Color.blue(start) * (1-ratio)
                        + android.graphics.Color.blue(end) * ratio
        );

        return android.graphics.Color.argb(
                a, r, g, b
        );
    }

    // =====================================
    // MENGHENTIKAN ANIMASI
    // =====================================

    @Override
    protected void onDestroy() {

        if (hologramAnimator != null) {
            hologramAnimator.cancel();
        }

        if (lineAnimator != null) {
            lineAnimator.cancel();
        }

        if (welcomeAnimator != null) {
            welcomeAnimator.cancel();
        }

        super.onDestroy();
    }
}