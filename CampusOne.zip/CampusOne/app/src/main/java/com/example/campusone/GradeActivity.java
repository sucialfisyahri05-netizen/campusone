
package com.example.campusone;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.util.ArrayList;

public class GradeActivity extends Activity {

    private JSONArray data;
    private ArrayList<String> rows;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grades);

        data = LocalData.get(this, "grades");

        rows = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                rows
        );

        ListView list = findViewById(R.id.gradeList);
        list.setAdapter(adapter);

        refresh();

        findViewById(R.id.addGrade).setOnClickListener(v ->
                editGrade(-1)
        );

        list.setOnItemClickListener((parent, view, position, id) ->
                editGrade(position)
        );

        list.setOnItemLongClickListener((parent, view, position, id) -> {

            new AlertDialog.Builder(this)
                    .setTitle("Hapus Nilai")
                    .setMessage("Yakin ingin menghapus nilai ini?")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus", (dialog, which) -> {
                        data.remove(position);
                        save();
                        refresh();
                    })
                    .show();

            return true;
        });
    }

    private void editGrade(int position) {

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(30, 10, 30, 10);

        EditText subject = new EditText(this);
        subject.setHint("Nama mata kuliah");

        EditText score = new EditText(this);
        score.setHint("Nilai (0 - 100)");
        score.setInputType(
                android.text.InputType.TYPE_CLASS_NUMBER
        );

        form.addView(subject);
        form.addView(score);

        if (position >= 0) {

            JSONObject old = data.optJSONObject(position);

            if (old != null) {
                subject.setText(old.optString("subject"));
                score.setText(old.optString("score"));
            }
        }

        new AlertDialog.Builder(this)
                .setTitle(position < 0 ? "Tambah Nilai" : "Edit Nilai")
                .setView(form)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", (dialog, which) -> {

                    String s = subject.getText().toString().trim();
                    String n = score.getText().toString().trim();

                    if (s.isEmpty() || n.isEmpty()) {
                        Toast.makeText(
                                this,
                                "Semua data wajib diisi",
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }

                    int value;

                    try {
                        value = Integer.parseInt(n);
                    } catch (NumberFormatException e) {
                        score.setError("Nilai harus berupa angka");
                        return;
                    }

                    if (value < 0 || value > 100) {
                        score.setError("Nilai harus antara 0 sampai 100");
                        return;
                    }

                    JSONObject item = new JSONObject();

                    try {
                        item.put("subject", s);
                        item.put("score", value);

                        if (position < 0) {
                            data.put(item);
                        } else {
                            data.put(position, item);
                        }

                    } catch (JSONException e) {
                        Toast.makeText(
                                this,
                                "Gagal menyimpan nilai",
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }

                    save();
                    refresh();

                    Toast.makeText(
                            this,
                            "Nilai berhasil disimpan",
                            Toast.LENGTH_SHORT
                    ).show();
                })
                .show();
    }

    private void save() {
        LocalData.save(this, "grades", data);
    }

    private void refresh() {

        rows.clear();

        for (int i = 0; i < data.length(); i++) {

            JSONObject item = data.optJSONObject(i);

            if (item != null) {
                rows.add(
                        item.optString("subject") +
                                "\nNilai: " +
                                item.optString("score")
                );
            }
        }

        adapter.notifyDataSetChanged();
    }
}