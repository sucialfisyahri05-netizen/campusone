
package com.example.campusone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AlphaAnimation;

public class MainActivity extends Activity {

    private Handler handler = new Handler(Looper.getMainLooper());

    private Runnable openLogin = () -> {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        setContentView(R.layout.activity_main);

        android.view.View logo = findViewById(R.id.logo);

        AlphaAnimation fade = new AlphaAnimation(0f, 1f);
        fade.setDuration(1500);

        logo.startAnimation(fade);

        handler.postDelayed(openLogin, 2500);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(openLogin);
        super.onDestroy();
    }
}
